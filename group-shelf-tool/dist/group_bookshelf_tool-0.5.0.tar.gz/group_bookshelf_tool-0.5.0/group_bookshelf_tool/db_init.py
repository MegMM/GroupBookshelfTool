from group_bookshelf_tool.components import GroupsTable

gr = GroupsTable()
gr.init_table()