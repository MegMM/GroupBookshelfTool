from group_bookshelf_tool import Config
config=Config()
log = config.set_logger(__package__, __name__)

from selenium import webdriver
from fake_useragent import UserAgent
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from random import randint
import re
import time

class DownloadGroupPages:
    def __init__(self, group_url:str, download_dir=None, per_page=None, sort_order=None):
        # log.debug(f"Calling DownloadGroupPages()")
        self.group_url:str = group_url
        self.download_dir:str = download_dir if download_dir else config.download_dir
        self.per_page:int = int(per_page) if per_page else 100
        self.sort_order:str = sort_order if sort_order else 'a'
        self.email_text:str = config.email
        self.password_text:str = config.password
        self.start_page:int = 1
        self.file_name_prefix:str = "page_"
        
    def sign_in(self):
        signInURL = "https://www.goodreads.com/user/sign_in"
        ua = UserAgent()
        user_agent = ua.random
        # user_agent = {'User-Agent': 'krumpli'}
        options = webdriver.ChromeOptions()
        options.add_argument("--headless=new")
        options.add_argument(f"--user-agent={user_agent}")
        options.add_argument("--disable-blink-features=AutomationControlled")
        service = Service(ChromeDriverManager().install())
        self.driver = webdriver.Chrome(service=service, options=options)
        try:
            # 1. Start with the Goodreads sign-in page
            self.driver.get(signInURL)
            # Wait for the "Sign in with email" button to be clickable
            sign_in_with_email_button = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, '/ap/signin')]//button[contains(text(), 'Sign in with email')]"))
            )
            # 2. Get the href attribute of the link
            parent_link = sign_in_with_email_button.find_element(By.XPATH, "..")
            link_href = parent_link.get_attribute("href")
            log.debug(f"The link URL is: {link_href}")
            # 3. Navigate to the link's URL
            self.driver.get(link_href)
            # 4. Wait for the email field to be present
            email_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "ap_email"))
            )
            log.debug("Email field found.")
            # 5. Locate the password field
            password_field = self.driver.find_element(By.ID, "ap_password")
            log.debug("Password field found.")
            # 6. Now you can interact with the email_field and password_field
            # For example, to enter text:
            email_field.send_keys(self.email_text)
            password_field.send_keys(self.password_text)
            # 7. Find the sign-in submit button (you'll need to inspect the page to get the correct locator)
            sign_in_button = self.driver.find_element(By.ID, "signInSubmit")  # Example ID
            sign_in_button.click()
            # 8. Wait for an element that indicates successful login
            # (Replace with an appropriate locator from the page after login)
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[contains(@href, '/user/show/')]"))
            )
            log.debug("\nLogin successful!\n")

        except Exception as e:
            log.error(f"ERROR: {e}")

    def find_last_page(self) -> int:
        """
        Find the total number of pages in the Goodreads bookshelf.
        Returns: the last page number
        """
        try:
            # Ensure we are on the first page
            full_url = self.group_url
            self.driver.get(full_url)

            # Wait for the element containing the total book count to be present
            # Use a precise XPath locator, parent::div
            parent_div = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//div/a[@class='actionLinkLite greyText']/parent::div"))
            )
            log.debug(f"{parent_div = }")
            # Extract the text from the parent div
            text = parent_div.text
            log.debug(f"{text = }")
            # Parse the text to extract the total book count
            # (Adapt this regex based on the format of the text)
            match = re.search(r"\((\d+)\)", text)  # Regex to extract the number within parentheses
            if match:
                total_books = int(match.group(1))
            else:
                log.error(f"Could not extract total book count from text: {text}")
                return self.start_page  # Or handle this case appropriately
            # Calculate the last page, Integer division with ceiling
            # This handles edge cases where total_books === self.per_page*num
            last_page = (total_books + self.per_page - 1) // self.per_page  
            log.debug(f"Total books: {total_books}, Last page: {last_page}")
            return last_page

        except Exception as e:
            log.error(f"Error finding last page: {e}")
            return self.start_page  # Or handle this case appropriately

    def get_full_url(self, page_num):
        ''' Construct the full url '''
        return f"{self.group_url}?page={page_num}&order={self.sort_order}&per_page={self.per_page}&utf8=%E2%9C%93"

    def start_downloads(self):
        """
        Downloads content from a paginated Goodreads bookshelf (or similar) to individual files.
        """
        try:
            # Iterate through pages and download content
            log.info("Signing in to Goodreads...")
            self.sign_in()

            log.info("Starting downloads...")
            delay_min, delay_max = (3, 5)
            sleep_time = randint(delay_min, delay_max)            
            last_page = self.find_last_page()
            # log.debug(f"{last_page = }")
            for page_num in range(self.start_page, last_page):
                # Construct the full URL for the current page
                # full_url = f"{self.group_url}?page={page_num}&order={self.sort_order}&per_page={self.per_page}&utf8=%E2%9C%93"
                full_url = self.get_full_url(page_num)
                log.debug(f"Fetching URL: {full_url}")

                self.driver.get(full_url)  # Navigate to the page

                # (Optional) Add a wait here if needed to ensure the page is fully loaded
                # For example:
                # WebDriverWait(self.driver, 10).until(
                #     EC.presence_of_element_located((By.CSS_SELECTOR, ".book"))  # Wait for a book element
                # )

                # Get the page source
                page_source = self.driver.page_source
                # Save the page source to a file
                file_name = f"{self.file_name_prefix}{page_num}.html"
                with open(file_name, "w", encoding="utf-8") as file:
                    file.write(page_source)
                log.debug(f"Saved page {page_num} to {file_name}")
                time.sleep(sleep_time)

        except Exception as e:
            log.error(f"ERROR: {e}")

        finally:
            self.driver.quit()


if __name__=="__main__":
    # Tests:
    # group_url = "https://www.goodreads.com/group/bookshelf/64285-queer-fantasy-science-fiction"
    # group_url = "https://www.goodreads.com/group/bookshelf/20149-m-m-romance"
    group_url = "https://www.goodreads.com/group/bookshelf/28965-gay-science-fiction"
    # group_url = "https://www.goodreads.com/group/bookshelf/49526-ya-lgbt-books"
    downloader = DownloadGroupPages(group_url)
    downloader.start_downloads()