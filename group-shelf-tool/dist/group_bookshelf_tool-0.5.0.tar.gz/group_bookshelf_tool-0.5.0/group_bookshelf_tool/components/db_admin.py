# import sqlalchemy as sq
from group_bookshelf_tool import Config
config = Config()
log = config.set_logger(__package__, __name__)

import json
import pickle
from sqlalchemy import text, inspect, update, select
from sqlalchemy.exc import NoResultFound, IntegrityError
from sqlalchemy.orm import Session, validates
from group_bookshelf_tool.components.models import (
    Group, Book, Download, GroupBook, TagURL, 
    Base, SessionLocal, metadata)
# from group_bookshelf_tool.build_db import group_table_data


class GeneralDB:
    # groups = GroupsTable()

    def get_db(self):
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    def list_all_tables (self):
        with SessionLocal() as db:
            # inspector = inspect()
            try:
                return inspect.get_table_names()
            except:
                return []

    def fetch_table_data(self, tablename):
        with SessionLocal() as db:
            sql_query = f"""
                select * from {tablename}
            """
            result = db.execute(text(sql_query)).fetchall()
        return result

    # download operation
    @validates('group_shelf_id')
    def update_folder_name(self, key, group_shelf_id):
        if group_shelf_id:
            # Get the group and update folder_name
            group = object_session(self).query(Group).get(group_shelf_id)
            if group:
                self.folder_name = group.folder_name
        return group_shelf_id


class GroupsTable(GeneralDB):
    def __init__(self):
        super().__init__()

    def init_table(self):
        self.create_groups_table()
        self.load_data()

    def load_data(self):
        with open(config.json_groups, 'r') as f:
            table_data = json.load(f)
        log.debug(f"{table_data = }")
        with SessionLocal() as db:
            for shelf in table_data:
                self.add_group_record(
                    group_name=shelf['group_name'],
                    folder_name=shelf['folder_name'],
                    url_str=shelf['url_str'],
                    )

    # DON'T use this because of table relationship chaos
    def drop_groups_table(self):
        with SessionLocal() as db:
            # This will properly handle foreign key relationships
            Base.metadata.drop_all(bind=engine, tables=[Group.__table__])

    def fetch_groups(self):
        with SessionLocal() as db:
            records = db.query(Group).all()
        # return fetch_table_data('groups')
        return records

    def fetch_groups_names(self):
        with SessionLocal() as db:
            return [shelf.group_name for shelf in db.query(Group).all()]

    def fetch_groups_folders(self):
        with SessionLocal() as db:
            return [shelf.folder_name for shelf in db.query(Group).all()]

    def fetch_group_folder(self, group_name=None):
        with SessionLocal() as db:
            try:
                record = db.query(Group).filter(Group.group_name == group_name).first() 
                if record: 
                    return record.folder_name 
            except:
                return None
            
    def fetch_group_url(self, ref_name=None):
        with SessionLocal() as db:
            try:
                record = db.query(Group).filter(Group.group_name == ref_name).first() 
                if record: 
                    return record.url_str 
                record = db.query(Group).filter(Group.folder_name == ref_name).first() 
                if record: 
                    return record.url_str 
                
            except: 
                return None

    def add_group_record(self, data=None, **kwargs):
        """ Model attributes: group_name, folder_name, url_str """
        values = data if data is not None else kwargs
        # log.debug(f"{type(values)}, {values}")
        required_fields = ['group_name', 'folder_name', 'url_str']
        if not all(field in values for field in required_fields):
            log.error(f"Data missing: requires group_name, folder_name, url_str")
            return False
        try:
            group_name = values.get('group_name')
            folder_name = values.get('folder_name')
            url_str = values.get('url_str')
            log.debug(f"{group_name = }, {folder_name = }, {url_str = }")
            with SessionLocal() as db:
                # log.debug(f"{folder_name = }")
                existing_group = db.query(Group).filter_by(folder_name=folder_name).first()
                if not existing_group:
                    new_group = Group(
                        group_name=group_name, 
                        folder_name=folder_name, 
                        url_str=url_str 
                        )
                    db.add(new_group)
                    db.commit()
                    return True
                else:
                    log.warning(f"Group with folder_name '{folder_name}' already exists")
                    return False
                
        except IntegrityError as e:
            log.error(f"Integrity error while adding group: {str(e)}")
            db.rollback()
            return False
        
        except Exception as e:
            log.error(f"Error adding group: {str(e)}")
            db.rollback()
            return False

    def update_group_record(self, data=None, **kwargs):
        values = data if data is not None else kwargs
        with SessionLocal() as db:
            folder_name = values.get('folder_name')
            group_name = values.get('group_name')
            url_str = values.get('url_str')
            existing_group = db.query(Group).filter_by(folder_name=folder_name).first()
            if not existing_group:
                log.error(f"No record found with {group_name = }, {folder_name = }, {url_str = }")
                db.rollback()
            else:
                GROUP = metadata.tables['groups']
                if folder_name is not None:
                    # old_data = 
                    upd = update(GROUP)
                    val = upd.values({"folder_name": folder_name})
                    cond = val.where(existing_group.c.folder_name == folder_name)
                    # pass


    def create_groups_table(self):
        with SessionLocal() as db:
            stmt = '''
                CREATE TABLE IF NOT EXISTS groups(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    group_name TEXT UNIQUE NOT NULL,
                    folder_name TEXT UNIQUE NOT NULL ,
                    url_str TEXT NOT NULL,
                    create_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    modified_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(folder_name, group_name)
                );
            '''
            db.execute(text(stmt))
            db.commit()


    def get_group_names(self):
        return self.fetch_groups_names()

    def get_group_folders(self):
        return self.fetch_groups_folders()

    def get_folder_name(self, group_name):
        return self.fetch_group_folder(group_name)

    def get_shelf_url(self, group_name=None, folder_name=None):
        ref_name = group_name if group_name is not None else folder_name
        return self.fetch_group_url(ref_name)

    def get_group_urls(self):
        folders = self.get_group_folders()
        for f in folders:
            log.info(f"URL for {f} is {self.get_group_url(f)}")

class BooksTable(GeneralDB):
    def __init__(self):
        super().__init__()

    def fetch_books(self):
        with SessionLocal() as db:
            records = db.query(Book).all()
        # return fetch_table_data('groups')
        return records



# def fetch_records_with_tags (self):
#     """ 
#     # Example usage:
#     # fetch_records_with_tags()
#     """
#     with SessionLocal() as db:
#         records = db.query(Book).all()
#         for record in records:
#             print(f"Record ID: {record.id}, Title: {record.title}, Author: {record.author}, Date: {record.date}")
#             for tag_url in record.tag_urls:
#                 print(f"  Tag: {tag_url.tag}, URL: {tag_url.url}")


# def add_record_with_tags(author, date, tags_urls):
#     """
#     # TOFIX: Add in all the columns required for Book
#     # tags_urls = [('tag1', 'http://url1.com'), ('tag2', 'http://url2.com')]
#     # new_record = add_record_with_tags('Author1', datetime.utcnow(), tags_urls)
#     # print(f"New record added: {new_record}")
#     """
#     with SessionLocal() as db:
#         new_record = Record(author=author, date=date)
#         for tag, url in tags_urls:
#             tag_url = db.query(TagURL).filter_by(tag=tag, url=url).first()
#             if not tag_url:
#                 tag_url = TagURL(tag=tag, url=url)
#             new_record.tag_urls.append(tag_url)
#         db.add(new_record)
#         db.commit()
#         db.refresh(new_record)
#         return new_record


# # Example usage

