from group_bookshelf_tool import Config
config = Config()
log = config.set_logger(__package__, __name__)

from datetime import datetime
from pathlib import Path
import os
from sqlalchemy.orm import Session
from PyQt6.QtCore import (
    Qt, 
    QProcess, 
    QSize, 
    pyqtSignal
)
from PyQt6.QtWidgets import (
    QFormLayout, 
    QHBoxLayout,  
    QVBoxLayout,                       
    QWidget, 
    QComboBox, 
    QLabel, 
    QLayout,
    QPushButton, 
)        
import sys

from group_bookshelf_tool.components.db_admin import GroupsTable
from group_bookshelf_tool.components.downloader import DownloadGroupPages
from group_bookshelf_tool.components.file_utils import DirectoryName


class DownloadTab(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.base_url = "https://www.goodreads.com"
        self.group_names = ['Group Names > ']
        groups = GroupsTable()
        self.group_names.extend(groups.get_group_names())
        self.group_name = ""
        self.shelf_folder = ""
        self.shelf_url = ""
        self.sort_order = ""
        self.download_dir = config.download_dir

        self.setContentsMargins(5, 20, 20, 0)
        page_layout = QVBoxLayout()
        self.setObjectName("download_tab")

        # create small widgets first
        self.group_combobox = QComboBox(self)
        self.group_combobox.addItems(self.group_names)
        self.group_combobox.currentIndexChanged.connect(self.on_group_selected)
        
        self.url_label = QLabel(self)
        self.url_label.setText("None selected")

        self.books_per_page_label = QLabel(self)
        self.books_per_page_label.setText("Books per page: 100")

        self.sort_order_choices = [('Sort order> ', ''), ('Ascending', 'a'), ('Descending', 'd')]
        self.sort_order_combobox = QComboBox(self)
        self.sort_order_combobox.addItems([order[0] for order in self.sort_order_choices])
        self.sort_order_combobox.setCurrentIndex(1)
        self.sort_order = self.sort_order_choices[1][1]
        self.sort_order_combobox.currentIndexChanged.connect(self.on_sort_selected)

        self.summary_label = QLabel(self) 
        self.summary_label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft) 
        self.summary_label.setWordWrap(True)
        self.download_dir_label = QLabel(self)
        self.download_dir_label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft) 
        self.download_dir_label.setWordWrap(True)

        form_layout = QFormLayout() 
        form_layout.addRow("Group:", self.group_combobox) 
        form_layout.addRow("URL:", self.url_label) 
        form_layout.addRow("Books per page:", self.books_per_page_label) 
        form_layout.addRow("Sort order:", self.sort_order_combobox)
        page_layout.addLayout(form_layout)
        page_layout.addWidget(self.summary_label)

        self.summary_label.setText(f""" 
    Summary of download options:
    Group> 
    Folder>
    URL>  
    Books per page> 100 
    Sort order> """)

        button_layout = QHBoxLayout()
        # execute, quit buttons
        self.download_button = QPushButton(text="Start Download", parent=self)
        self.download_button.setObjectName("download_button")
        self.download_button.setMinimumSize(140, 50)
        self.download_button.clicked.connect(self.start_download)
        self.quit_button = QPushButton(text="Quit", parent=self)
        self.quit_button.setObjectName("quit_button")
        self.quit_button.setMinimumSize(140, 50)
        self.quit_button.clicked.connect(self.quit)
        # button layout
        button_layout.addStretch()
        button_layout.addWidget(self.download_button, alignment=Qt.AlignmentFlag.AlignCenter)
        button_layout.addWidget(self.quit_button, alignment=Qt.AlignmentFlag.AlignCenter)
        button_layout.addStretch()

        page_layout.addLayout(button_layout)
        self.setLayout(page_layout)
        self.update_summary_label() # Updates Display

    def on_group_selected(self, index):
        # set group_name first, then shelf_data
        self.group_name = self.group_combobox.itemText(index)
        self.shelf_folder = db.get_folder_name(group_name=self.group_name)
        self.shelf_url = db.get_shelf_url(group_name=self.group_name)
        self.shelf_data = {'group_name': self.group_name,
                           'shelf_folder': self.shelf_folder,
                           'shelf_url': self.shelf_url,
                           }
        log.debug(config.pretty_dict(self.shelf_data))
        dn = DirectoryName(self, self.download_dir)
        download_folder = dn.set_download_folder(self.shelf_data)
        self.download_dir = download_folder['download_path']
        log.debug(f"{self.download_dir = }")
        self.shelf_url = f"{self.base_url}/{self.shelf_url}"
        log.debug(f"{self.shelf_data = }")
        self.url_label.setText(f"{self.shelf_url}")
        self.shelf_data.update({'shelf_url': self.shelf_url})
        # self.passback_shelf_data()
        self.update_summary_label()

    def on_sort_selected(self, index):
        self.sort_order = self.sort_order_combobox.itemText(index)
        self.update_summary_label()

    def update_summary_label(self): 
        # selected_choice = self.sort_order_combobox.currentText() 
        def print_download_directory():
            if self.download_dir:
                return f"\n    Download destination> {self.download_dir}"
            else:
                return ""
        
        self.summary_label.setText(f""" 
    Summary of download options:
    Group> {self.group_name}
    Folder> {self.shelf_folder}
    URL> {self.shelf_url} 
    Books per page> 100 
    Sort order> {self.sort_order}{print_download_directory()}
    """)
        
    def start_download(self):
        log.debug(f"Starting download...")
        download = DownloadGroupPages(group_url=self.shelf_url, 
                                      download_dir=config.download_dir,
                                      per_page=100, 
                                      sort_order='a')
        download.start_downloads()

      
    def quit(self):
        self.parent.quit_app()