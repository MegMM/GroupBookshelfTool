#! bookshelf.py
import os
import subprocess
import logging
from pathlib import WindowsPath
import sqlite3
import csv
from group_bookshelf_tool.app import *
# from group_bookshelf_tool.configs import BaseConfig, JSONLogger

configlog = JSONLogger(__package__, __name__)
configlog.get_logger()
logging.debug(f"{configlog.pkg = }, {configlog.name = }")

DBPATH = BaseConfig.DBPATH
bookshelf_table = 'bookshelf'
download_table = 'download_records'

def init_db(reset_db=False):
    if DBPATH.exists() and reset_db:
        logging.info(f"... Removing database file: {DBPATH} ...")
        with sqlite3.connect(DBPATH) as conn:
            with conn.cursor() as c:
                c.execute(f"SELECT 1 FROM {tablename} LIMIT 1")
        #     except sqlite3.Error as e:
        #         logging.error(f"Error while removing database file: {e}")
        # finally:
        #     conn.close()

        os.remove(DBPATH)
        logging.info(f"Database file removed successfully: {DBPATH}")

    try:
        # _init_db(print_table_meta)
        logging.info(f"... Creating new database ...")
        add_tables()
        add_bookshelf_data()
    except:
        logging.debug(f"{DBPATH.exists() = }")

from contextlib import contextmanager
@contextmanager
def db_operation(DBPATH):
    conn = sqlite3.connect(DBPATH)
    try:
        cur = conn.cursor()
        yield cur
    except Exception as e:
        # do something with exception
        conn.rollback()
        raise e
    else:
        conn.commit()
    finally:
        cur.close()
        conn.close()

def table_exists(tablename):
    with db_operation(DBPATH) as cur:
        try:
            cur.execute(f"SELECT 1 FROM {tablename} LIMIT 1")
            exists = True
        except sqlite3.Error:
            exists = False
    return exists

def remove_existing_table(tablename):
    drop_table = f'''DROP TABLE IF EXISTS {tablename};'''
    with db_operation(DBPATH) as cur:
        cur.execute(drop_table)

def remove_all_tables(cursor, conn):
    logging.debug(f"  ... Dropping all tables ...")
    possible_tables = ['bookshelves', bookshelf_table, 'download_record',
                       download_table, 'bookshelf_download_relation',
                       'bookshelf_download_table']
    [remove_existing_table(cursor, conn, tablename) for tablename in possible_tables]

def add_table(tablename, new_table):
    with db_operation(DBPATH) as cur:
        tablename_exists = table_exists(tablename)

    if tablename_exists:
        logging.info(f"     Tables exists: '{tablename}'")
        return

    logging.info(f"     Creating table: '{tablename}'")
    with db_operation(DBPATH) as cur:
        try:
            cur.execute(new_table)
        except:
            logging.error(f"  Uknown error adding table: '{tablename}' ")

    if tablename_exists:
        logging.info(f"  Table added: '{tablename}'")
    else:
        logging.error(f"  Table wasn't added: '{tablename}' ")

def add_tables():
    # only adds if table doesn't exist already
    bookshelf_table = f'''
    CREATE TABLE IF NOT EXISTS bookshelf(
        id INTEGER PRIMARY KEY NOT NULL,
        shelf_label TEXT NOT NULL,
        directory_name TEXT NOT NULL,
        url TEXT NOT NULL,
        creation_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_date DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    '''
    download_table = f'''
    CREATE TABLE IF NOT EXISTS download_record(
        id INTEGER PRIMARY KEY NOT NULL,
        bookshelf_id INTEGER NOT NULL,
        directory_path TEXT NOT NULL,
        page_size INTEGER,
        sort_order TEXT,
        creation_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        download_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_bookshelf FOREIGN KEY (bookshelf_id) REFERENCES bookshelf(id) ON DELETE CASCADE);
    '''
    bookshelf_download_table = f'''
    CREATE TABLE bookshelf_download_relation (
        bookshelf_id INTEGER NOT NULL,
        download_id INTEGER NOT NULL,
        PRIMARY KEY (bookshelf_id, download_id),
        FOREIGN KEY (bookshelf_id) REFERENCES bookshelves(id),
        FOREIGN KEY (download_id) REFERENCES download_record(id)
    );
    '''
    table_list = [("bookshelf", bookshelf_table),
                  ("download_record", download_table),
                  ("bookshelf_download_relation", bookshelf_download_table)]
    for table in table_list:
        add_table(table[0], table[1])

def add_bookshelf_data():
    ### 
    # just adds bookshelf data for now. 
    # need to generate a JSON file for download records
    # ... OR make a backup database.
    ###
    csv_file = BaseConfig.CONFIGSPATH / "group_shelves.csv"
    with open(csv_file, 'r') as file:
        contents = csv.reader(file)
        next(contents)  # Skip Header row
        sql_insert = '''
            INSERT OR IGNORE INTO bookshelf (shelf_label, directory_name, url)
            VALUES (?, ?, ?)
        '''
        with db_operation(DBPATH) as cur:
            try:
                # Using "executemany" instead of "execute" for multiple records
                cur.executemany(sql_insert, contents)
                logging.info("Bookshelf CSV data added to database")
            except sqlite3.IntegrityError:
                logging.info("Some records already exist and were ignored.")

def table_to_dict(tablename):
    def dict_factory(cursor, row):
        fields = [column[0] for column in cursor.description]
        return {key: value for key, value in zip(fields, row)}

    sql_query = f"""
        select * from {tablename}
    """
    with sqlite3.connect(DBPATH) as conn:
        conn.row_factory = dict_factory
        cur = conn.cursor()
        result = cur.execute(sql_query).fetchall()
        cur.close()
    # returns list of dicts
    return [shelf for shelf in result]

def get_table_data(tablename):
    sql_query = f"""
        select * from {tablename}
    """
    with db_operation(DBPATH) as cur:
        cur.execute(sql_query)
        return cur.fetchall()

def insert_table_data(tablename, dict_data):
    # use dict format to add columns and values
    # sql_query = f"""
    # insert into tablename (col1, col2, col3)
    # values (val1, val2, val3)
    # """
    # with db_operation(DBPATH) as cur:
    #     cur.execute(sql_query)
    pass

if table_exists(bookshelf_table):
    shelves_dict = table_to_dict(bookshelf_table)
if table_exists(download_table):
    download_records_dict = table_to_dict(download_table)