from group_bookshelf_tool import Config
config = Config()
log = config.set_logger(__package__, __name__)

import os
import sys
from PyQt6.QtGui import (
    QColor,
    QPalette,) 
from PyQt6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPushButton,
    QSizePolicy,
    QTextEdit,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from group_bookshelf_tool.components.download_tab import DownloadTab
from group_bookshelf_tool.components.db_admin_tab import DBAdminTab

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Selenium in PyQt6")
        self.setGeometry(100, 100, 900, 700)
        self.web_view = None

        self.main_widget = QWidget()
        self.main_layout = QVBoxLayout(self.main_widget)

        self.quit_button = QPushButton("Quit Application")
        self.quit_button.setObjectName("long_btn")
        self.quit_button.clicked.connect(self.quit_app)
        self.main_layout.addWidget(self.quit_button)

        self.download_button = QPushButton("Download Page Test")
        self.download_button.clicked.connect(self.download_page)
        self.main_layout.addWidget(self.download_button)

        self.tab_widget = QTabWidget()
        self.main_layout.addWidget(self.tab_widget)
        # self.setup_browser_tab()

        # self.tab_widget.addTab(self.browser_tab, "Goodreads Browser")
        self.tab_widget.addTab(DownloadTab(self), "Download Shelf")
        self.tab_widget.addTab(DBAdminTab(self), "DB Admin")
        self.main_layout.addWidget(self.tab_widget)
        self.setCentralWidget(self.main_widget)

    def download_page(self):
        pass

    def quit_app(self):
        # if self.selenium_thread:
        #     self.selenium_thread.stop()
        self.close()

    def closeEvent(self, event):
        self.quit_app()
        event.accept()


def set_app_style(app):
    # stylesheet=r"C:\Goodreads Bookshelf Tool\selenium-archiver\group_bookshelf_tool\assets\style.qss"
    with open(config.stylesheet, 'r') as file:
        style_sheet = file.read()
    app.setStyleSheet(style_sheet)
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor("#121212"))
    palette.setColor(QPalette.ColorRole.WindowText, QColor("#dddddd"))
    palette.setColor(QPalette.ColorRole.Base, QColor("#121212"))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor("#39516b"))
    palette.setColor(QPalette.ColorRole.Highlight, QColor("#587d9f"))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor("white"))
    app.setPalette(palette)
    return app


def create_app():
    app = QApplication(sys.argv)
    app = set_app_style(app)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    create_app()
