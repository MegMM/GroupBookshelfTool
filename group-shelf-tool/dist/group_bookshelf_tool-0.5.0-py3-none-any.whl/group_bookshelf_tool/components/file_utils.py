from group_bookshelf_tool import Config
config = Config()
log = config.set_logger(__package__, __name__)
#log.debug(f"config {__package__}.{__name__}")

from datetime import datetime
from pathlib import Path
import os
# from group_bookshelf_tool.components import db_interface as db
from group_bookshelf_tool.components.db_admin import GroupsTable

class DirectoryUtils:
    def __init__(self):
        pass

    def make_new_dir(self, path):
        """
        Desc: Make a new directory, add parents if needed.
        """
        # log.debug(f"Making directory for {path}")
        try:
            path.mkdir(parents=True)
        except FileExistsError as exception:
            log.error(f"make_new_dir(): {path} directory already exists.")

    def move_directory(self, current, destination):
        """
        Desc: Move files to new archive destination
        """
        if not current.is_dir():
            self.dir_exists(destination)
        else:
            current.rename(destination)

    def is_empty(self, path):
        """
        Desc: Validation check that path is empty
        """
        return not any(path.iterdir())


class DirectoryName(DirectoryUtils):
    def __init__(self, parent, download_dir=None, processed_dir=None):
        super().__init__()
        self.download_path = self.provide_full_path_path(config.download_dir, download_dir)
        self.processed_path = self.provide_full_path_path(config.processed_dir, processed_dir)

        self.date_obj_formats = ['%m/%d/%Y %H:%M:%S', '%m/%d/%y %H:%M:%S', '%m/%d/%Y',
                                 '%m/%d/%Y']
        self.date_folders_formats = ['%b%d_%H%M', '%b%d']
        self.creation_date = datetime.today()
        self.date_obj = self.creation_date
        self.format_extension = ""

    def provide_full_path_path(self, parent, subpath):
        if subpath is None:
            return parent
        else:
            subpath_str = str(Path(subpath).resolve())
            if subpath_str.startswith(parent):
                return subpath_str
            else:
                combined_path = Path(parent) / Path(subpath).name
                return str(combined_path)

    def is_valid_year(self, year_str):
        try:
            year = int(year_str)
            return 2000 <= year <= 3000 
        except ValueError:
            log.error(f"Invalid year value")

    def is_valid_shelf(self, shelf_str):
        try:
            groups = GroupsTable()
            return shelf_str in groups.get_group_folders()
        except:
            return False
        
    def check_date_format(self, date_str): 
        if isinstance(date_str, Path):
            date_str = str(date_str)
        for fmt in self.date_folders_formats: 
            try: 
                return datetime.strptime(date_str, fmt) 
            except ValueError: 
                continue 
        return False

    def _get_year(self):
        return f'{self.date_obj.year}'

    def _get_todays_date(self):
        return f"{self.date_obj.strftime('%b%d')}"

    def _get_timestamp(self):
        return f"{self.date_obj.strftime('%H%M')}"

    def set_output_filename(self, data=None):
        keywords = ['processed_path', 'shelf_folder', 'month_day', 'year', 'format_extension']
        if data:
            for k, v in data.items():
                setattr(self, k, v)
        if all(hasattr(self, key) for key in keywords) and all(getattr(self, key) for key in keywords): 
            output_file = Path(self.processed_path) / self.shelf_folder / rf"{self.month_day}_{self.year}.{self.format_extension}"
            if output_file.is_file() and output_file.exists():
                reprocessed_tag = f"reprocessed_{self._get_todays_date()}_{self._get_timestamp()}"
                output_file = output_file.with_name(f"{output_file.stem}_{reprocessed_tag}{output_file.suffix}")
                # log.debug(f"{output_file = }")
                # output_file = self.get_timestamped_folder_path(output_file)
            return output_file

        else:

            raise ValueError("No data to set parsing output filename")

    def set_download_page_name(self, page_num):
        return self.download_path / f'page_{page_num}.html'

    def set_download_folder(self, data=None):
        # log.debug(f"{type(data) = }, {data}")
        if data is not None:
            for k, v in data.items():
                setattr(self, k, v)
                log.debug(f"self.{k}: {v}")

        keywords = ['shelf_folder', 'year', 'month_day']
        has_all_attributes = all(hasattr(self, key) for key in keywords)
        if has_all_attributes:
            has_attribute_values = all(getattr(self, key) for key in keywords)
            if has_attribute_values:
                pass

        elif not self.download_path or not self.shelf_folder :
            log.error(f"Data values are missing: {keywords}")
        self.date_obj = datetime.today()
        folder_data = {
            'year': self._get_year(),
            'month_day': self._get_todays_date(),
            'timestamp': self._get_timestamp(),
            }
        year_month_day_timestamp = rf"{folder_data['year']}/{folder_data['month_day']}_{folder_data['timestamp']}"
        shelf_date_string = f'{self.shelf_folder}/{year_month_day_timestamp}'
        folder_data.update({'download_path': Path(self.download_path) / shelf_date_string})
        try:
            self.make_new_dir(folder_data['download_path'])
        except:
            if len(os.listdir(folder_data['download_path'])) == 0:
                pass
            else:
                self.set_download_folder()
        log.debug(f"{folder_data = }")
        return folder_data

# class TestDirectoryName(DirectoryUtils):
#     def __init__(self, download_path=None):
#         super().__init__()
#         output_dirs = config.get_output_dirs()
#         setattr(self, 'user_root', output_dirs.get("root"))
#         setattr(self, 'download_path', download_path if download_path \
#                 else output_dirs.get("download"))
#         setattr(self, 'processed_path', output_dirs.get("processed"))


if __name__ == "__main__":
    dn = DirectoryName()
    shelf_name = 'LGBTQ_Fantasy_SciFi'
    data = dn.set_download_folder({'shelf_folder': shelf_name})
    log.debug(f"{data = }")